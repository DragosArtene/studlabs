package com.proiect.colectiv.model;

public enum Role {
    USER, ADMINISTRATOR;
}
