package com.proiect.colectiv.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginUserDTO {

    private String username;
    private String password;
}
